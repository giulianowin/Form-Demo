import React from 'react';
import CareAssessmentForm from './components/CareAssessmentForm';

function App() {
  return <CareAssessmentForm />;
}

export default App;